# Tap & Score
A simple Android tap game.

Rules:
- Tap the moving target as many times as possible in 30 seconds.
- Your best score is saved on the device.
- Offline game; no API key required.

Build with GitHub Actions or Android Studio.
